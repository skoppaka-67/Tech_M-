codebase_information = {


    'VB':{
        'folder_name':'WebApplications',
        'extension':'aspx'
    },

    'code_location':'D:\\WORK\\VB_IMP\\*'
}


vb = codebase_information['VB']['folder_name']
code_location = codebase_information['code_location']
vb_path = code_location + '\\*'
vb_component_path = "D:\\WORK\\VB_IMP\\vbcomponent"