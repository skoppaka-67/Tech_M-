database = {
    'hostname':'localhost',
    'port':27017,

    'database_name':'BNSF_NAT'

}




file ={'D:\\BNSF\\POC\\NAT': '*.NAT'}

cl_file={'D:\\BNSF\\POC\\COPY':"*"}
CopyPath = 'D:\\BNSF\\POC\\COPY'

codebase_information = {

    'COBOL':{
        'folder_name':'NAT',
        'extension':'NAT'
    },
    'COPYBOOK':{
        'folder_name':'COPYBOOK',
        'extension':'CPY'
    },

    'INCLUDE':{
        'folder_name':'COPYBOOK',
        'extension':'CPY'
    },
    'JCL': {
        'folder_name': 'JCL',
        'extension': 'JCL'
    },
    'PROC': {
        'folder_name': 'PROC',
        'extension': 'PROC'
    },
    'SYSIN': {
        'folder_name': 'SYSIN',
        'extension': 'SYSIN'
    },
    'SCRIPTS':{
        'folder_name': 'SCRIPTS',
        'extension': 'SCR' },


    'file_location':'D:\\BNSF\\POC\\NAT',
    'condition_path':"D:\\BNSF\\POC\\sample.xlsx",

    'code_location': 'D:\\BNSF\\POC'

}
