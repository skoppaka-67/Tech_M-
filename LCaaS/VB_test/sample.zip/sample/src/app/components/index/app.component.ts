/**
 * Created By : Sangwin Gawande (http://sangw.in)
 */

import { Component } from '@angular/core';

@Component({
	selector: 'app-root',
	templateUrl: './app.component.html',
	styleUrls: ['./app.component.css']
})


export class AppComponent {
	title = 'Student Management By Sangwin Gawande';

	// Add few students for initial listing
	studentsList = [
	{	
		id : 1,
		first_name : "Sam",
		last_name : "Smith",
		email : "ssmith@yopmail.com",
		phone : 9999999999,
		department : "Science"
	},
	{
		id : 2,
		first_name : "Harry",
		last_name : "Prince",
		email : "hprince@yopmail.com",
		phone : 9999999998,
		department : "Commerce"
	},
	{
		id : 3,
		first_name : "Nelson",
		last_name : "Alexandar",
		email : "nalex@yopmail.com",
		phone : 9999999997,
		department : "Science"
	},
	{
		id : 4,
		first_name : "Ben",
		last_name : "Affleck",
		email : "baffleck@yopmail.com",
		phone : 9999999996,
		department : "Arts"
	},
	{
		id : 5,
		first_name : "Joe",
		last_name : "Micheal",
		email : "jmicheal@yopmail.com",
		phone : 9999999995,
		department : "Engineering"
	}
	];

	constructor() {
		// Save students to localStorage
		localStorage.setItem('students', JSON.stringify(this.studentsList));
	}
}

/**
 * Created By : Sangwin Gawande (http://sangw.in)
 */
