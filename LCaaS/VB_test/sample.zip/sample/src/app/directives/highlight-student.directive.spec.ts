/**
 * Created By : Sangwin Gawande (http://sangw.in)
 */

import { HighlightStudentDirective } from './highlight-student.directive';

describe('HighlightStudentDirective', () => {
  it('should create an instance', () => {
    const directive = new HighlightStudentDirective();
    expect(directive).toBeTruthy();
  });
});

/**
 * Created By : Sangwin Gawande (http://sangw.in)
 */
