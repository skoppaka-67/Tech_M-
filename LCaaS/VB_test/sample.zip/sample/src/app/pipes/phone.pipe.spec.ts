/**
 * Created By : Sangwin Gawande (http://sangw.in)
 */

import { PhonePipe } from './phone.pipe';

describe('PhonePipe', () => {
  it('create an instance', () => {
    const pipe = new PhonePipe();
    expect(pipe).toBeTruthy();
  });
});


/**
 * Created By : Sangwin Gawande (http://sangw.in)
 */